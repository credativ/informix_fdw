{ DATABASE regression  delimiter | }

grant dba to "informix";











{ TABLE "informix".foo row size = 8 number of columns = 2 index size = 0 }

{ unload file name = foo__00100.unl number of rows = 3 }

create table "informix".foo 
  (
    id integer,
    value integer
  );

revoke all on "informix".foo from "public" as "informix";

{ TABLE "informix".bla row size = 4 number of columns = 1 index size = 0 }

{ unload file name = bla__00101.unl number of rows = 1 }

create table "informix".bla 
  (
    id integer
  );

revoke all on "informix".bla from "public" as "informix";

{ TABLE "informix".inttest row size = 14 number of columns = 3 index size = 13 }

{ unload file name = intte00102.unl number of rows = 10003 }

create table "informix".inttest 
  (
    f1 bigint,
    f2 integer,
    f3 smallint
  );

revoke all on "informix".inttest from "public" as "informix";

{ TABLE "informix".serial_test row size = 2015 number of columns = 3 index size = 0 }

{ unload file name = seria00103.unl number of rows = 4 }

create table "informix".serial_test 
  (
    f1 serial8 not null ,
    f2 lvarchar(2000),
    flag "informix".boolean
  );

revoke all on "informix".serial_test from "public" as "informix";

{ TABLE "informix".date_test row size = 4 number of columns = 1 index size = 0 }

{ unload file name = date_00104.unl number of rows = 4 }

create table "informix".date_test 
  (
    datum date
  );

revoke all on "informix".date_test from "public" as "informix";

{ TABLE "informix".datetime_test row size = 225 number of columns = 4 index size = 0 }

{ unload file name = datet00105.unl number of rows = 2 }

create table "informix".datetime_test 
  (
    f1 datetime year to second not null ,
    comment lvarchar(200),
    dt date not null ,
    id int8
  );

revoke all on "informix".datetime_test from "public" as "informix";

{ TABLE "informix".nvarchar_test row size = 201 number of columns = 1 index size = 0 }

{ unload file name = nvarc00106.unl number of rows = 4 }

create table "informix".nvarchar_test 
  (
    val nvarchar(200)
  );

revoke all on "informix".nvarchar_test from "public" as "informix";

{ TABLE "informix".byte_test row size = 60 number of columns = 2 index size = 0 }

{ unload file name = byte_00107.unl number of rows = 1 }

create table "informix".byte_test 
  (
    id integer,
    data byte
  );

revoke all on "informix".byte_test from "public" as "informix";

{ TABLE "informix".text_test row size = 60 number of columns = 2 index size = 0 }

{ unload file name = text_00108.unl number of rows = 2 }

create table "informix".text_test 
  (
    id integer,
    data text
  );

revoke all on "informix".text_test from "public" as "informix";

{ TABLE "informix".dec_test row size = 6 number of columns = 1 index size = 0 }

{ unload file name = dec_t00109.unl number of rows = 2 }

create table "informix".dec_test 
  (
    value decimal(9,2)
  );

revoke all on "informix".dec_test from "public" as "informix";

{ TABLE "informix".bar_serial row size = 105 number of columns = 2 index size = 0 }

{ unload file name = bar_s00110.unl number of rows = 1 }

create table "informix".bar_serial 
  (
    id serial not null ,
    name varchar(100)
  );

revoke all on "informix".bar_serial from "public" as "informix";




grant select on "informix".foo to "public" as "informix";
grant update on "informix".foo to "public" as "informix";
grant insert on "informix".foo to "public" as "informix";
grant delete on "informix".foo to "public" as "informix";
grant index on "informix".foo to "public" as "informix";
grant select on "informix".bla to "public" as "informix";
grant update on "informix".bla to "public" as "informix";
grant insert on "informix".bla to "public" as "informix";
grant delete on "informix".bla to "public" as "informix";
grant index on "informix".bla to "public" as "informix";
grant select on "informix".inttest to "public" as "informix";
grant update on "informix".inttest to "public" as "informix";
grant insert on "informix".inttest to "public" as "informix";
grant delete on "informix".inttest to "public" as "informix";
grant index on "informix".inttest to "public" as "informix";
grant select on "informix".serial_test to "public" as "informix";
grant update on "informix".serial_test to "public" as "informix";
grant insert on "informix".serial_test to "public" as "informix";
grant delete on "informix".serial_test to "public" as "informix";
grant index on "informix".serial_test to "public" as "informix";
grant select on "informix".date_test to "public" as "informix";
grant update on "informix".date_test to "public" as "informix";
grant insert on "informix".date_test to "public" as "informix";
grant delete on "informix".date_test to "public" as "informix";
grant index on "informix".date_test to "public" as "informix";
grant select on "informix".datetime_test to "public" as "informix";
grant update on "informix".datetime_test to "public" as "informix";
grant insert on "informix".datetime_test to "public" as "informix";
grant delete on "informix".datetime_test to "public" as "informix";
grant index on "informix".datetime_test to "public" as "informix";
grant select on "informix".nvarchar_test to "public" as "informix";
grant update on "informix".nvarchar_test to "public" as "informix";
grant insert on "informix".nvarchar_test to "public" as "informix";
grant delete on "informix".nvarchar_test to "public" as "informix";
grant index on "informix".nvarchar_test to "public" as "informix";
grant select on "informix".byte_test to "public" as "informix";
grant update on "informix".byte_test to "public" as "informix";
grant insert on "informix".byte_test to "public" as "informix";
grant delete on "informix".byte_test to "public" as "informix";
grant index on "informix".byte_test to "public" as "informix";
grant select on "informix".text_test to "public" as "informix";
grant update on "informix".text_test to "public" as "informix";
grant insert on "informix".text_test to "public" as "informix";
grant delete on "informix".text_test to "public" as "informix";
grant index on "informix".text_test to "public" as "informix";
grant select on "informix".dec_test to "public" as "informix";
grant update on "informix".dec_test to "public" as "informix";
grant insert on "informix".dec_test to "public" as "informix";
grant delete on "informix".dec_test to "public" as "informix";
grant index on "informix".dec_test to "public" as "informix";
grant select on "informix".bar_serial to "public" as "informix";
grant update on "informix".bar_serial to "public" as "informix";
grant insert on "informix".bar_serial to "public" as "informix";
grant delete on "informix".bar_serial to "public" as "informix";
grant index on "informix".bar_serial to "public" as "informix";
















revoke usage on language SPL from public ;

grant usage on language SPL to public ;





create index "informix".inttest_f1_idx on "informix".inttest (f1) 
    using btree ;








 



