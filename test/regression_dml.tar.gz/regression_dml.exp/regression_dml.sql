{ DATABASE regression_dml  delimiter | }

grant dba to "informix";











{ TABLE "informix".foo row size = 8 number of columns = 2 index size = 0 }

{ unload file name = foo__00100.unl number of rows = 3 }

create table "informix".foo 
  (
    id integer,
    value integer
  );

revoke all on "informix".foo from "public" as "informix";

{ TABLE "informix".bla row size = 4 number of columns = 1 index size = 0 }

{ unload file name = bla__00101.unl number of rows = 1 }

create table "informix".bla 
  (
    id integer
  );

revoke all on "informix".bla from "public" as "informix";

{ TABLE "informix".inttest row size = 14 number of columns = 3 index size = 13 }

{ unload file name = intte00102.unl number of rows = 0 }

create table "informix".inttest 
  (
    f1 bigint,
    f2 integer,
    f3 smallint
  );

revoke all on "informix".inttest from "public" as "informix";

{ TABLE "informix".nvarchar_test row size = 201 number of columns = 1 index size = 0 }

{ unload file name = nvarc00106.unl number of rows = 4 }

create table "informix".nvarchar_test 
  (
    val nvarchar(200)
  );

revoke all on "informix".nvarchar_test from "public" as "informix";

{ TABLE "informix".byte_test row size = 60 number of columns = 2 index size = 0 }

{ unload file name = byte_00107.unl number of rows = 1 }

create table "informix".byte_test 
  (
    id integer,
    data byte
  );

revoke all on "informix".byte_test from "public" as "informix";

{ TABLE "informix".text_test row size = 60 number of columns = 2 index size = 0 }

{ unload file name = text_00108.unl number of rows = 2 }

create table "informix".text_test 
  (
    id integer,
    data text
  );

revoke all on "informix".text_test from "public" as "informix";

{ TABLE "informix".dec_test row size = 6 number of columns = 1 index size = 0 }

{ unload file name = dec_t00109.unl number of rows = 2 }

create table "informix".dec_test 
  (
    value decimal(9,2)
  );

revoke all on "informix".dec_test from "public" as "informix";

{ TABLE "informix".bar_serial row size = 105 number of columns = 2 index size = 0 }

{ unload file name = bar_s00110.unl number of rows = 1 }

create table "informix".bar_serial 
  (
    id serial not null ,
    name varchar(100)
  );

revoke all on "informix".bar_serial from "public" as "informix";

{ TABLE "informix".varchar_test row size = 613 number of columns = 4 index size = 13 }

{ unload file name = varch00113.unl number of rows = 0 }

create table "informix".varchar_test 
  (
    id bigint not null ,
    v1 varchar(200,3) not null ,
    v2 lvarchar(200) not null ,
    v3 nvarchar(200) not null ,
    primary key (id) 
  );

revoke all on "informix".varchar_test from "public" as "informix";

{ TABLE "informix".longvarchar_test row size = 32750 number of columns = 2 index size = 13 }

{ unload file name = longv00117.unl number of rows = 0 }

create table "informix".longvarchar_test 
  (
    id bigint not null ,
    v1 lvarchar(32739) not null ,
    primary key (id) 
  );

revoke all on "informix".longvarchar_test from "public" as "informix";

{ TABLE "informix".bigserial_test row size = 29 number of columns = 2 index size = 13 }

{ unload file name = bigse00119.unl number of rows = 0 }

create table "informix".bigserial_test 
  (
    id bigserial not null ,
    v1 varchar(20) not null ,
    primary key (id) 
  );

revoke all on "informix".bigserial_test from "public" as "informix";

{ TABLE "informix".text_byte_test row size = 122 number of columns = 3 index size = 15 }

{ unload file name = text_00120.unl number of rows = 0 }

create table "informix".text_byte_test 
  (
    id int8 not null ,
    v1 byte not null ,
    v2 text not null ,
    primary key (id) 
  );

revoke all on "informix".text_byte_test from "public" as "informix";

{ TABLE "informix".datetime_test row size = 28 number of columns = 4 index size = 15 }

{ unload file name = datet00121.unl number of rows = 0 }

create table "informix".datetime_test 
  (
    id int8 not null ,
    v1 datetime year to fraction(3) not null ,
    v2 date not null ,
    v3 datetime hour to second,
    primary key (id) 
  );

revoke all on "informix".datetime_test from "public" as "informix";

{ TABLE "informix".date_test row size = 4 number of columns = 1 index size = 0 }

{ unload file name = date_00122.unl number of rows = 0 }

create table "informix".date_test 
  (
    val date
  );

revoke all on "informix".date_test from "public" as "informix";

{ TABLE "informix".serial_test row size = 4 number of columns = 1 index size = 0 }

{ unload file name = seria00123.unl number of rows = 0 }

create table "informix".serial_test 
  (
    id serial not null 
  );

revoke all on "informix".serial_test from "public" as "informix";

{ TABLE "informix".serial8_test row size = 10 number of columns = 1 index size = 0 }

{ unload file name = seria00124.unl number of rows = 0 }

create table "informix".serial8_test 
  (
    id serial8 not null 
  );

revoke all on "informix".serial8_test from "public" as "informix";

{ TABLE "informix".decimal_test row size = 15 number of columns = 3 index size = 0 }

{ unload file name = decim00125.unl number of rows = 0 }

create table "informix".decimal_test 
  (
    f1 decimal(10,0) not null ,
    f2 decimal(2,2),
    f3 decimal(10,9)
  );

revoke all on "informix".decimal_test from "public" as "informix";

{ TABLE "informix".interval_test row size = 12 number of columns = 3 index size = 0 }

{ unload file name = inter00126.unl number of rows = 0 }

create table "informix".interval_test 
  (
    f1 interval year to month,
    f2 interval day to second,
    f3 interval hour to minute
  );

revoke all on "informix".interval_test from "public" as "informix";

{ TABLE "informix".float_test row size = 12 number of columns = 2 index size = 0 }

{ unload file name = float00129.unl number of rows = 0 }

create table "informix".float_test 
  (
    val1 float,
    val2 smallfloat
  );

revoke all on "informix".float_test from "public" as "informix";




grant select on "informix".foo to "public" as "informix";
grant update on "informix".foo to "public" as "informix";
grant insert on "informix".foo to "public" as "informix";
grant delete on "informix".foo to "public" as "informix";
grant index on "informix".foo to "public" as "informix";
grant select on "informix".bla to "public" as "informix";
grant update on "informix".bla to "public" as "informix";
grant insert on "informix".bla to "public" as "informix";
grant delete on "informix".bla to "public" as "informix";
grant index on "informix".bla to "public" as "informix";
grant select on "informix".inttest to "public" as "informix";
grant update on "informix".inttest to "public" as "informix";
grant insert on "informix".inttest to "public" as "informix";
grant delete on "informix".inttest to "public" as "informix";
grant index on "informix".inttest to "public" as "informix";
grant select on "informix".nvarchar_test to "public" as "informix";
grant update on "informix".nvarchar_test to "public" as "informix";
grant insert on "informix".nvarchar_test to "public" as "informix";
grant delete on "informix".nvarchar_test to "public" as "informix";
grant index on "informix".nvarchar_test to "public" as "informix";
grant select on "informix".byte_test to "public" as "informix";
grant update on "informix".byte_test to "public" as "informix";
grant insert on "informix".byte_test to "public" as "informix";
grant delete on "informix".byte_test to "public" as "informix";
grant index on "informix".byte_test to "public" as "informix";
grant select on "informix".text_test to "public" as "informix";
grant update on "informix".text_test to "public" as "informix";
grant insert on "informix".text_test to "public" as "informix";
grant delete on "informix".text_test to "public" as "informix";
grant index on "informix".text_test to "public" as "informix";
grant select on "informix".dec_test to "public" as "informix";
grant update on "informix".dec_test to "public" as "informix";
grant insert on "informix".dec_test to "public" as "informix";
grant delete on "informix".dec_test to "public" as "informix";
grant index on "informix".dec_test to "public" as "informix";
grant select on "informix".bar_serial to "public" as "informix";
grant update on "informix".bar_serial to "public" as "informix";
grant insert on "informix".bar_serial to "public" as "informix";
grant delete on "informix".bar_serial to "public" as "informix";
grant index on "informix".bar_serial to "public" as "informix";
















revoke usage on language SPL from public ;

grant usage on language SPL to public ;





create index "informix".inttest_f1_idx on "informix".inttest (f1) 
    using btree ;








 



